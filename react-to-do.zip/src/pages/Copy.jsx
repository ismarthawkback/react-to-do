import React from "react";
import { Wrapper } from "../components/Todo";

export default function Copy() {
  return (
    <div>
      <Wrapper>
        <h1>Copy-Right</h1>

        <p>Brother.. Eeuww...!</p>
        <p> No copy right Brotha... </p>

        <br />
        <br />
        <p> You can find the source code at : </p>
        <a href="" target="blank">
          Github{" "}
        </a>
        <br />
        <br />
      </Wrapper>
    </div>
  );
}
