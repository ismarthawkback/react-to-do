import React from "react";
import { styled } from "styled-components";

const BigTextInput = styled.input`
    width ; 100%;
`;

export default function TodoForm() {
  return <BigTextInput />;
}
